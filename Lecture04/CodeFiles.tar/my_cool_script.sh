# This is my better script
# Done using different approaches
# This script is not going to work
# 最后加一句中文
# This script is not good
# 也试一试生僻字児臥，和日语あいうえお
